﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Device.Location;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Controls.Maps;
using Microsoft.Phone.Tasks;

namespace BingMaps.Demo
{
    public partial class MainPage : PhoneApplicationPage
    {
        GeoCoordinateWatcher watcher;
        Pushpin actualPosition;

        Dictionary<int, GeoCoordinate> placesList;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            watcher = new GeoCoordinateWatcher ();
            watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
            watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);

            watcher.MovementThreshold = 20;

            placesList = new Dictionary<int, GeoCoordinate>();
            placesList.Add(1, new GeoCoordinate(6.24957407984444, -75.5916213989258));
            placesList.Add(2, new GeoCoordinate(6.24914747662375, -75.5645847320557));
            placesList.Add(3, new GeoCoordinate(6.23182709239987, -75.5881881713867));

            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            
            foreach (int key in this.placesList.Keys)
            {
                Pushpin newLocation = new Pushpin();
                newLocation.Template = (ControlTemplate)(App.Current.Resources["PushpinSuggested"]);
                newLocation.Content = key;
                newLocation.Location = this.placesList[key];
                map1.Children.Add(newLocation);
            }

            watcher.Start();
        }

        void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    if (watcher.Permission == GeoPositionPermission.Denied)
                    {
                        statusTextBlock.Text = "La aplicación no tiene permisos sobre el servicio de localización";
                    }
                    else
                    {
                        statusTextBlock.Text = "El servicio de localización no esta funcionando en el dispositivo";
                    }
                    break;

                case GeoPositionStatus.Initializing:
                    break;

                case GeoPositionStatus.NoData:
                    statusTextBlock.Text = "Los datos de localización no están disponibles";
                    break;
                case GeoPositionStatus.Ready:
                    statusTextBlock.Text = "El servicio de localización está disponible";
                    break;
            }
        }

        void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            if (actualPosition != null)
                map1.Children.Remove(actualPosition);

            actualPosition = new Pushpin();
            actualPosition.Template = (ControlTemplate)(App.Current.Resources["PushpinActualPosition"]);
            actualPosition.Location = e.Position.Location;
            actualPosition.Content = "Yo";
            map1.Children.Add(actualPosition);

            map1.SetView(actualPosition.Location, 14);
        }

        private void startLocationButton_Click(object sender, RoutedEventArgs e)
        {
            //startLocationButton.IsEnabled = false;
            //stopLocationButton.IsEnabled = true;
            watcher.Start();
        }

        private void stopLocationButton_Click(object sender, RoutedEventArgs e)
        {
            //startLocationButton.IsEnabled = true;
            //stopLocationButton.IsEnabled = false;
            watcher.Stop();
        }

        private void map1_Tap(object sender, GestureEventArgs e)
        {
            var puntoPantalla = new Point(e.GetPosition(map1).X, e.GetPosition(map1).Y);
            var puntoMapa = map1.ViewportPointToLocation(puntoPantalla);

            Pushpin newLocation = new Pushpin();
            newLocation.Template = (ControlTemplate)(App.Current.Resources["PushpinSuggested"]);
            newLocation.Location = puntoMapa;
            map1.Children.Add(newLocation);

        }

        private void btnChangeView_Click(object sender, System.EventArgs e)
        {
            if (map1.Mode is RoadMode)
            {
                map1.Mode = new AerialMode();
            }
            else
            {
                map1.Mode = new RoadMode();
            }
        }
    }
}