﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.IO;

namespace Eafit.LeerEscribirArchivo
{
    public partial class MainPage : PhoneApplicationPage
    {
        private string nombreArchivo = "Prueba.txt";

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, RoutedEventArgs e)
        {
            // Obtener instancia del Almacenamiento Aislado
            IsolatedStorageFile isolatedStorage = IsolatedStorageFile.GetUserStoreForApplication();

            // Instancia de StreamWriter para crear el archivo
            using (StreamWriter writer = new StreamWriter(new IsolatedStorageFileStream(nombreArchivo, FileMode.Append, FileAccess.Write, isolatedStorage)))
            {
                // Copiado de datos al archivo
                writer.WriteLine(String.Format("Nombre: {0}", txtNombre.Text));
                writer.WriteLine(String.Format("Ciudad: {0}", txtCiudad.Text));
                writer.Close();
            }

            txtNombre.Text = txtCiudad.Text = string.Empty;
            
            MessageBox.Show("Datos guardados!");
        }

        private void btnLeer_Click(object sender, RoutedEventArgs e)
        {
            lstContenidoArchivo.Items.Clear();

            // Obtener instancia del Almacenamiento Aislado
            IsolatedStorageFile isolatedStorage = IsolatedStorageFile.GetUserStoreForApplication();

            // Verificar si el archivo existe para evitar errores
            if (isolatedStorage.FileExists(nombreArchivo))
            {
                // Instancia de StreamReader para obtener y leer archivo almadenado
                using (StreamReader reader = new StreamReader(isolatedStorage.OpenFile(nombreArchivo, FileMode.Open, FileAccess.Read)))
                {
                    // Lectura del archivo linea por linea, escribiÃ©ndolo en el control en pantalla.
                    while (!reader.EndOfStream)
                    {
                        lstContenidoArchivo.Items.Add(reader.ReadLine());
                    }
                }
            }
            else
            {
                MessageBox.Show("El archivo a leer no existe!");
            }
        }
    }
}