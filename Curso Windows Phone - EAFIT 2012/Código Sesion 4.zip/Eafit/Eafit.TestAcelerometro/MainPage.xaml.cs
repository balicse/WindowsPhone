﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;

namespace Eafit.TestAcelerometro
{
    public partial class MainPage : PhoneApplicationPage
    {
        private Accelerometer accel = null;
        
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            InicializarAcelerometro();
        }

        private void InicializarAcelerometro()
        {
            if (Accelerometer.IsSupported)
            {
                accel = new Accelerometer();

                // Si necesitamos la actualización cada cierto intervalo de tiempo.
                // accel.TimeBetweenUpdates = TimeSpan.FromSeconds(1);
                accel.CurrentValueChanged += new EventHandler<SensorReadingEventArgs<AccelerometerReading>>(accel_CurrentValueChanged);
            }
            else
            {
                MessageBox.Show("No se puede usar el acelerómetro!");
            }
        }

        void accel_CurrentValueChanged(object sender, SensorReadingEventArgs<AccelerometerReading> e)
        {
            Dispatcher.BeginInvoke(() => ActualizarCoordenadas(e.SensorReading));
        }

        private void ActualizarCoordenadas(AccelerometerReading e)
        {
            txtX.Text = String.Format("X = {0}", e.Acceleration.X);
            txtY.Text = String.Format("Y = {0}", e.Acceleration.Y);
            txtZ.Text = String.Format("Z = {0}", e.Acceleration.Z);
        }

        private void btnIniciar_Click(object sender, RoutedEventArgs e)
        {
            accel.Start();
        }

        private void btnDetener_Click(object sender, RoutedEventArgs e)
        {
            accel.Stop();
        }
    }
}