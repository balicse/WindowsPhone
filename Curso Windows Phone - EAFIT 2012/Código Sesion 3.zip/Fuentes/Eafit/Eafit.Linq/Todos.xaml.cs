﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Eafit.Linq
{
    public partial class Todos : PhoneApplicationPage
    {
        private string cadenaConexion = "isostore:/Gastos.sdf";

        public Todos()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(Todos_Loaded);
        }

        void Todos_Loaded(object sender, RoutedEventArgs e)
        {
            using (GastosDataContext contexto = new GastosDataContext(this.cadenaConexion))
            {
                List<Gastos> listaGasto = (from g in contexto.Gastos
                                          select g).ToList();

                listaGasto.ForEach(p => this.lstTodos.Items.Add(p.Descripcion + " - " + p.Valor));
            }
        }
    }
}