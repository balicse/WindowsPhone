﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Eafit.Linq
{
    public partial class MainPage : PhoneApplicationPage
    {
        private string cadenaConexion = "isostore:/Gastos.sdf";
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            using (GastosDataContext contexto = new GastosDataContext(this.cadenaConexion))
            {
                if (!contexto.DatabaseExists())
                {
                    contexto.CreateDatabase();
                }
            }
        }

        private void btnGuardar_Click(object sender, RoutedEventArgs e)
        {
            Gastos nuevoGasto = new Gastos();
            nuevoGasto.Descripcion = this.txtDescripcion.Text;
            nuevoGasto.Valor = Convert.ToInt32(this.txtValor.Text);

            using (GastosDataContext contexto = new GastosDataContext(this.cadenaConexion))
            {
                contexto.Gastos.InsertOnSubmit(nuevoGasto);
                contexto.SubmitChanges();
            }

            MessageBox.Show("Gasto guardado: " + nuevoGasto.Codigo);
            this.txtDescripcion.Text = string.Empty;
            this.txtValor.Text = string.Empty;
        }

        private void btnConsultar_Click(object sender, RoutedEventArgs e)
        {
            using (GastosDataContext contexto = new GastosDataContext(this.cadenaConexion))
            {
                Gastos gastoConsultado = (from g in contexto.Gastos
                                          where g.Codigo == Convert.ToInt32(this.txtCodigo.Text)
                                          select g).SingleOrDefault();

                if (gastoConsultado == null)
                    MessageBox.Show("El código no existe");
                else
                {
                    this.txtDescripcion.Text = gastoConsultado.Descripcion;
                    this.txtValor.Text = gastoConsultado.Valor.ToString();
                }
            }
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            using (GastosDataContext contexto = new GastosDataContext(this.cadenaConexion))
            {
                Gastos gastoConsultado = (from g in contexto.Gastos
                                          where g.Codigo == Convert.ToInt32(this.txtCodigo.Text)
                                          select g).SingleOrDefault();

                if (gastoConsultado == null)
                    MessageBox.Show("El código no existe");
                else
                {
                    contexto.Gastos.DeleteOnSubmit(gastoConsultado);
                    contexto.SubmitChanges();
                }
            }
        }

        private void btnConsultarTodos_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Todos.xaml", UriKind.Relative));
        }
    }
}