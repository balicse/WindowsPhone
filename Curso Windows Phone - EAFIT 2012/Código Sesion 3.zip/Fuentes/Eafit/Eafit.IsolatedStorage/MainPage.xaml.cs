﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;


namespace Eafit.IsolatedStorage
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, RoutedEventArgs e)
        {
            IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;

            if (settings.Contains("nombre"))
            {
                settings["nombre"] = txtNombre.Text;
            }
            else
            {
                settings.Add("nombre", txtNombre.Text);
            }

            MessageBox.Show("Valor guardado!");
        }

        private void btnLeer_Click(object sender, RoutedEventArgs e)
        {
            IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;

            if (settings.Contains("nombre"))
            {
                MessageBox.Show("Hola, " + settings["nombre"]);
            }
            else
            {
                MessageBox.Show("No se encontró información!");
            }
        }
    }
}