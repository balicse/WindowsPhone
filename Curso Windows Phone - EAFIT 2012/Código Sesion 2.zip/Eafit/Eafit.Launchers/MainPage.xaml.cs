﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using System.Device.Location;
using System.Windows.Media.Imaging;

  
namespace Eafit.Launchers
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //WebBrowserTask launcher = new WebBrowserTask();
            //launcher.Uri = new Uri(textBox1.Text, UriKind.Absolute);
            //launcher.Show();

            BingMapsTask bing = new BingMapsTask();
            bing.ZoomLevel = 5;
            bing.Center = new GeoCoordinate(6.19917600444067,-75.5785396099091);
            bing.Show();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            AddressChooserTask chooser = new AddressChooserTask();
            chooser.Completed += new EventHandler<AddressResult>(chooser_Completed);
            chooser.Show();
        }

        void chooser_Completed(object sender, AddressResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                MessageBox.Show("Contacto: " + e.Address);
            }
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            CameraCaptureTask chooser = new CameraCaptureTask();
            chooser.Completed += new EventHandler<PhotoResult>(chooser_Completed);
            chooser.Show();
        }

        void chooser_Completed(object sender, PhotoResult e)
        {
            if (e.TaskResult == TaskResult.OK)
            {
                var picture = e.ChosenPhoto;

                BitmapImage imgBitmap = new BitmapImage();
                imgBitmap.SetSource(picture);

                //Asignamos la imagen a un objeto de la aplicación
                image1.Source = imgBitmap;
            }

        }

    }
}