﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Controls.Maps;
using System.Device.Location;

namespace Eafit.Mapas
{
    public partial class MainPage : PhoneApplicationPage
    {

        private GeoCoordinateWatcher gps;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            gps = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
            gps.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(gps_PositionChanged);
            gps.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(gps_StatusChanged);
            gps.MovementThreshold = 20;
            gps.Start();
        }

        void gps_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    MessageBox.Show("GPS Deshabilitdo");
                    break;
                case GeoPositionStatus.Initializing:
                    break;
                case GeoPositionStatus.NoData:
                    break;
                case GeoPositionStatus.Ready:
                    break;
                default:
                    break;
            }

        }

        void gps_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            Pushpin pin = new Pushpin();
            pin.Location = e.Position.Location;
            pin.Template = (ControlTemplate)(App.Current.Resources["Pushpin"]);
            

            map1.Children.Add(pin);
            map1.SetView(e.Position.Location, 14);
            

        }


        private void mnuVistaCarretera_Click(object sender, System.EventArgs e)
        {
            map1.Mode = new RoadMode();
        }

        private void mnuVistaAerea_Click(object sender, System.EventArgs e)
        {
            map1.Mode = new AerialMode();
        }

        private void btnAumentar_Click(object sender, System.EventArgs e)
        {
            double zoom = map1.ZoomLevel;
            map1.ZoomLevel = ++zoom;
        }

        private void btnDisminuir_Click(object sender, System.EventArgs e)
        {
            double zoom = map1.ZoomLevel;
            map1.ZoomLevel = --zoom;
        }
    }
}