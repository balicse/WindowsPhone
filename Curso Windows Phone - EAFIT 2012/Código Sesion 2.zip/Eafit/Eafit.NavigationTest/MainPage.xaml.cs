﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Eafit.NavigationTest
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnNavegar_Click(object sender, RoutedEventArgs e)
        {
            string nombre = "sorey";
            string apellido = "garcia";
            //string strUri = "/Pagina2.xaml?nombre=" + nombre;
            string strUri = String.Format("/Pagina2.xaml?nombre={0}&apellido={1}", nombre, apellido);
            Uri uri = new Uri(strUri, UriKind.Relative);

            NavigationService.Navigate(uri);
        }
    }
}