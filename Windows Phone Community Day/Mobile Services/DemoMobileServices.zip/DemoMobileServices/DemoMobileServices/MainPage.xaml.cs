﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using DemoMobileServices.Resources;
using Microsoft.WindowsAzure.MobileServices;
using Microsoft.Phone.Notification;

namespace DemoMobileServices
{
    public partial class MainPage : PhoneApplicationPage
    {
        static string applicationUrl = "https://mobileservicesdemotest.azure-mobile.net/";
        static string applicationKey = "vQqXgMmBSYKsYQtFDuyiAdlnjufxrl57";
        public static MobileServiceClient mobileClient = new MobileServiceClient(applicationUrl, applicationKey);

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += MainPage_Loaded;

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private void btnSava_Click(object sender, RoutedEventArgs e)
        {
            Persona p = new Persona()
            {
                Nombre = txtNombre.Text,
                Telefono = txtDireccion.Text,
                Canal = App.CanalActual.ChannelUri.ToString()
            };

            IngresarPersona(p);
        }

        private async void IngresarPersona(Persona p)
        {
            IMobileServiceTable<Persona> personas = mobileClient.GetTable<Persona>();
            await personas.InsertAsync(p);

            MessageBox.Show("Persona ingresada");
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}

        private MobileServiceUser user;

        private async System.Threading.Tasks.Task Authenticate()
        {
            string message = string.Empty;
            while (user == null)
            {
                try
                {
                    user = await mobileClient.LoginAsync(MobileServiceAuthenticationProvider.Twitter);
                    message = string.Format("Autenticado {0}!", user.UserId);
                }
                catch (InvalidOperationException)
                {
                    message = "Es requerido autenticarse";
                }
            }

            MessageBox.Show(message);
        }

        async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            await Authenticate();
        }

    }
}